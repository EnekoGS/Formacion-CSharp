﻿namespace Ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombreUsuario; // Declaramos la variable de tipo "string" para nombre de Usuario.
            string contraseñaUsuario; // Declaramos la variable de tipo "string" para contraseña de Usuario.

            Console.WriteLine("Por favor, introduzca nombre y contraseña.");
            // Solicitamos el nombre y contraseña.
            Console.WriteLine("Nombre de usuario: ");
            nombreUsuario = Console.ReadLine() ?? "Nombre obligatorio"; 
            // Nos aseguramos de que nos de error por valor "Nulo"

            // Condiciones para validar o no el inicio de sesión.
            if (nombreUsuario == "FORMACION") { // => Si el nombre de Usuario es correcto...
		int errores = 0; // declaramos una variable de tipo "int" para el contador de errores.

        // El bucle "Do" & "While" nos permitirá aplicar más de un intento para la contraseña.
		do { 
	        Console.WriteLine("Contraseña: "); // => ...Nos pedirá la contraseña
        	contraseñaUsuario = Console.ReadLine() ?? "Contraseña obligatoria";
            if ( contraseñaUsuario == "TALIO") { // Si la contraseña es correcta...
                 Console.WriteLine("CONTRASEÑA CORRECTA"); // ...Recibiremos este mensaje y el código habrá finalizado
            } else {
                 Console.WriteLine("CONTRASEÑA INCORRECTA"); //...Y si no, nos pedirá de nuevo la contraseña.
                 errores++; // Este contador subirá cada vez que cometamos un error
                   }
        } while ( contraseñaUsuario != "TALIO" && errores < 3 ); // Aquí tenemos dos condiciones:
                                                                 // Si la contraseña no coincide con "TALIO"
                                                                 // El número de errores no llega a tres
		if ( errores == 3 ) {
			Console.WriteLine("ERROR DE CONTRASEÑA."); // => Si el número de errores llega a tres, ya no habrán más intentos.
		}
            } else {
                Console.WriteLine("USUARIO RECHAZADO :("); // => Si no escribimos bien el nombre de Usuario, se finalizará el código
            } 
        }
    }
}
    