﻿namespace Ejercicio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declaramos la variable de "temperatura".
            int temperatura;
            // Recibiremos un mensaje en la consola.
            Console.WriteLine("Por favor, introduzca una temperatura. Será medida en Cº.");
            // El "ReadLine" nos solicitará introducir un valo numérico.
            // Para ello, convertiremos la variable "temperatura", que es un "String", en un "Int".
            temperatura = int.Parse(Console.ReadLine()??"0");
            // Si el Readline retorna un nulo, el parse recibirá una nueva cadena para evitar errores.
            // Asignamos al valor nulo un nuevo valor, que es "0".
            if (temperatura < -50 ) // si la temperatura está por debajo de -50, es "Sólido".
            {
                Console.WriteLine("Sólido"); // Lo mostramos en la consola.
            }
            else if (temperatura >= -50 && temperatura < 0) // Si la temperatura está entre -50 y 0, es "Gélido".
            {
                Console.WriteLine("Gélido"); // Lo mostramos en la consola.
            }
            else if (temperatura >= 0 && temperatura < 25) // Si la temperatura está entre 0 y 25, es "Frío".
            {
                Console.WriteLine("Frío"); // Lo mostramos en la consola.
            }
            else if (temperatura >= 25 && temperatura < 75) // Si la temperatura está entre 25 y 75, es "Caliente".
            {
                Console.WriteLine("Caliente"); // Lo mostramos en la consola.
            }
            else if (temperatura >= 75 && temperatura <= 100) // Si la temperatura está entre 75 y 100, está "Hirviendo".
            {
                Console.WriteLine("Hirviendo"); // Lo mostramos en la consola.
            }
            else 
            {
                Console.WriteLine("Gaseoso"); // Lo mostramos en la consola.
            }
        }
    }
}
