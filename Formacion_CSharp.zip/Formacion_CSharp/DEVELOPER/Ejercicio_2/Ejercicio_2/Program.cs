﻿namespace Ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string mes;
            int dias = 3;

            Console.WriteLine("Por favor, seleccione un més del año.");
            //mes = int.Parse(console.ReadLine()?? "0");

            switch (dias)
            {

            }
        }
    }
}
