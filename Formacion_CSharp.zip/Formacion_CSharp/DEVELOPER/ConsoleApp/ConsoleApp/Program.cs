﻿namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.Write("Dime tu nombre: ");
            //string? nombre = Console.ReadLine();
            //Console.WriteLine($"Hola {nombre}");

            //------------------------------------------

            //int a = 10;
            //a++;

            //Console.WriteLine(a);

            //------------------------------------------

            //int edad = 18;

            //if (edad >= 18 && edad <= 30)
            //{
            //    Console.WriteLine("Mayor");
            //}
            //else
            //{
            //    Console.WriteLine("Menor");   
            //}

            //------------------------------------------

            for (int i = 0; i < 10; i++) 
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine( i );
                }
            }
        }
    }
}
